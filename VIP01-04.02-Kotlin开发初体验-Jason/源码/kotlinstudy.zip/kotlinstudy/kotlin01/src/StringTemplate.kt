/*
fun main() {
    val orgin = "Jack"
    val dest = "Rose"
    println("$orgin love $dest")

    val flag = false
    println("Answer is ${if(flag) "我可以" else "对不起"}")
}*/

