 fun doSomething(age:Int, flag:Boolean):String{
    return "result"
}

fun fix(name:String, age:Int = 2){
    println(name + age)
}

 fun `**~special function with weird name~**`(){
     println("I am weird")
 }


fun main() {
    doSomething(20,false)
    println(fix(age=5,name="jack"))

    `**~special function with weird name~**`()

    MyJava.`is`()
    //TODO("nothing")
}



