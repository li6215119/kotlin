/*
const val MAX = 100

fun main() {
    var hello:String = "Hello World"
    //hello = "Hello My World"
    println(hello)
    val age = 20
    println(age)
}*/
