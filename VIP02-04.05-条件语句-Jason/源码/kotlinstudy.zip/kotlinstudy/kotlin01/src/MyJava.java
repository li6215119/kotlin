/**
 * @author ningchuanqi
 * @description
 */
public class MyJava {

    public static void is(){
        System.out.println("is method invoked");
    }

}
