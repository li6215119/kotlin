/*
fun main() {
    var str = readLine()
    println(str)
}*/
