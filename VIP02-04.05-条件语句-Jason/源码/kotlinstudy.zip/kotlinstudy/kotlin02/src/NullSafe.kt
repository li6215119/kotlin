
/*fun main() {
    var str = getStr()
    //如果str为null，不调用count，因为肯定会报空指针异常
    var i = str?.count()
    println(i)
    println(str)
}*/


fun getStr():String?{
    return null
}


/*fun main() {
    var str = getStr()?.let{
        if(it.isNotBlank()){
            it.capitalize()
        }else{
            "butterfly"
        }
    }

    println(str)
}*/


/*
fun main() {
    val str = getStr()
    val i = str!!.count()
    println(i)
    println(str)
}*/

fun main2() {
    var str = readLine()
    if(str != null){
        str = str.capitalize()
    }else{
        println("为null.")
    }

    //val strWithSafe = str ?: "butterfly"

    //str = str?.capitalize()?.plus(" is great.");

    //let代替if，else，?: 空合并操作符（elvis）缺损值
    val strWithSafe = str?.let{ it.capitalize()} ?: "butterfly"

    println(str)
}
