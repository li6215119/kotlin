fun main() {
    "The people's Republic of China.".forEach {
        print("$it*")
    }
}