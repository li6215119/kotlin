const val NAMES = "jack,jacky,jason"
fun main() {
    val data = NAMES.split(',')

    //解构赋值
    val (origin,dest,proxy) = NAMES.split(',')
    println("$origin $dest $proxy")
}