import java.io.File

fun main() {
    val file = File("E://i have a dream_copy.txt")
    val result = file.run {
        readText().contains("great")
    }
    println(result)

    val result2 = "The people's Republic of China.".run(::isTooLong)
    //isTooLong("The people's Republic of China.")

    //函数式编程，灵活
    //移动端，前端和后端有很大区别
    "The people's Republic of China."
        .run (::isTooLong)
        .run (::showMessage)
        .run (::println)
}

fun isTooLong(name:String) = name.length >= 10

fun showMessage(isLong:Boolean):String{
    return if(isLong){
        "Name is too long."
    }else{
        "Please rename."
    }
}