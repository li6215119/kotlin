fun main() {
    val isToLong = with("The people's Republic of China.") {
        length >= 0
    }
}