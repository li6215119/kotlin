fun main() {
    //字符串不可变
    val str1 = "Jason"
    val str2 = "jason".capitalize()

    println("$str1 $str2")
    println(str1 == str2)
    println(str1 === str2)
}