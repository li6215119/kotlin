const val NAME = "Jimmy's friend"
fun main() {
    val index = NAME.indexOf('\'')
    val str = NAME.substring(0 until index)
    println(str)
}
