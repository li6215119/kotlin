import java.io.File

fun main() {
    val intArray = intArrayOf(10, 30, 40, 20)

    listOf(10,30).toIntArray()

    val arrayOfFiles = arrayOf(File("xx"), File("yy"))
}