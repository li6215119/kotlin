import kotlin.math.absoluteValue

class Player{
    var name = "abc"
        get() = field.capitalize()
        set(value){
            field = value.trim()
        }

    var age = 10
        get() = field.absoluteValue
        private set(value) {
            field = value.absoluteValue
        }

    val rolledValue
        get() = (1..60).shuffled().first()

    var words:String? = "hEllO"

    fun fix(){
        //words = words?.toLowerCase()?.capitalize()
        words = words?.let {
            it.toLowerCase().capitalize()
        }
    }

}

fun main() {
    val player = Player()
    player.name = " abc "
    //println(player.name)

    //player.age = -20
    //println(player.age)

    println(player.rolledValue)
    println(player.rolledValue)

    player.fix()
    println(player.words)
}