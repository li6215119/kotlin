fun main() {
    val set = setOf("Jack", "Jason", "Jacky")
    //set[1]
    println(set.elementAt(1))
}