import java.io.File

//伴生对象
open class ConfigMap{

    companion object{
        private const val PATH = "xxx"
        fun load() = File(PATH).readBytes()
    }

}

fun main() {
    ConfigMap.load()
}