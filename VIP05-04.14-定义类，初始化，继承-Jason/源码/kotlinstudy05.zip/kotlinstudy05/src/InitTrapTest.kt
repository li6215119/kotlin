class Player6(){
    val blood = 100

    init{
        val bloodBonus = blood.times(4)
    }

}