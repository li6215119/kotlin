class Player8(_name: String) {
    val playerName: String = initPlayerName()

    val name: String = _name
    private fun initPlayerName() = name

}

fun main() {
    println(Player8("Jack").playerName)
}