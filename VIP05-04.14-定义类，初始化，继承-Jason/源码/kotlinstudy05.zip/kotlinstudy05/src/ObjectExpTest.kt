open class Player9{
    //一些更多的复杂功能
    //此处省略一万个函数
    open fun load() = "loading nothing..."
}

fun main() {
    //只用一次
    //对象表达式
    val p = object : Player9(){
        override fun load() = "anonymous class load..."
    }
    println(p.load())
}