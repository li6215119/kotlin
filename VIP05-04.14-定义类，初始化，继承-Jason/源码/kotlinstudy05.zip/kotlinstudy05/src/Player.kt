class Player(
    _name: String,
    _age: Int,
    _isNormal: Boolean
) {

    var name = _name
        get() = field.capitalize()
        private set(value) {
            field = value.trim()
        }
    var age = _age
    var isNumber = _isNormal
}

fun main() {
    var player = Player("Jack",20,true)
}