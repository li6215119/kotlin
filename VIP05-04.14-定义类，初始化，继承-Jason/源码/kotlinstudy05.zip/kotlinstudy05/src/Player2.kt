class Player2(
    _name: String,
    var age: Int,
    val isNormal: Boolean
) {

    var name = _name
        get() = field.capitalize()
        private set(value) {
            field = value.trim()
        }

    //次构造函数
    constructor(name: String) : this(name, 100, false)

    constructor(name: String, age: Int) : this(name, age, false) {
        this.name = name.toUpperCase()
    }
}

fun main() {
    var p1 = Player2("Jack", 20, true)
    var p2 = Player2("Jack")
    var p3 = Player2("Jack",18)
    println(p3.name)

}