//object，对象声明
object ApplicationConfig{
    init {
        println("loading config...")
    }

    fun setSomething(){
        println("set something")
    }
}

fun main() {
    ApplicationConfig.setSomething()
    ApplicationConfig.setSomething()
}