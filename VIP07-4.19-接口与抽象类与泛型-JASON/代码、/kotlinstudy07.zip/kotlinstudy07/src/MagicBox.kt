/*
class MagicBox<T>(item: T) {
    private var subject: T = item
}

class Boy(val name: String, val age: Int)

class Dog(val weight: Int)

fun main() {
    val box1:MagicBox<Boy> = MagicBox(Boy("Jack",20))
    val box2:MagicBox<Dog> = MagicBox(Dog(20))
}*/
