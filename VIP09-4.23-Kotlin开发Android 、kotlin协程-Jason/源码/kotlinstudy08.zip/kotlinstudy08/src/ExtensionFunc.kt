/*

//给字符串追加若干个感叹号
fun String.addExt(amount: Int = 1) = this + "!".repeat(amount)

fun Any.easyPrint() = println(this)

fun main() {
    println("abc".addExt(2))
    "abc".easyPrint()
    15.easyPrint()
}*/
