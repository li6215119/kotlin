/*
fun String.addExt(amount: Int = 1) = this + "!".repeat(amount)

fun Any.easyPrint(): Any {
    println(this)
    return this
}

fun main() {
    "abc".easyPrint().addExt(2).easyPrint()
}*/
