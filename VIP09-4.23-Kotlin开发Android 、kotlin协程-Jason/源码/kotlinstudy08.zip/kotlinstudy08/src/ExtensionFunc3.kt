/*

fun String.addExt(amount: Int = 1) = this + "!".repeat(amount)



fun <T> T.easyPrint(): T {
    println(this)
    return this
}

fun main() {
    "abc".easyPrint().addExt(2).easyPrint()

    val i = "abc".let {
        50
    }
}
*/
