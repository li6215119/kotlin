/*

val String.numVowels
    get() = count { "aeiou".contains(it) }


fun <T> T.easyPrint(): T {
    println(this)
    return this
}

fun main() {
    "The people's Republic of China".numVowels.easyPrint()
}
*/
