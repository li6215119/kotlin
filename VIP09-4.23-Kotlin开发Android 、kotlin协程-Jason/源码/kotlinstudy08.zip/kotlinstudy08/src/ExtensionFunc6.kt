import com.jason.kotlin.extension.randomTake as randomizer

fun main() {

    val list = listOf("Jason", "Jack", "Tom")
    val set = setOf("Jason", "Jack", "Tom")

    list.randomizer()
}